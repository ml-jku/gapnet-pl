pyll
===============================

Provides a variety of convenience routines for pytorch projects

Copyright (c) 2016-2017 Markus Hofmarcher and Michael Widrich, Institute
of Bioinformatics, Johannes Kepler University Linz, Austria